package uc.benkkstudio.bsvideostatus.ui.search;

import android.view.View;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public interface SearchView extends MvpView {
    void startActivity(View view, String tag);
    void callFragmentProfile(int userId);
}
