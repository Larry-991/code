package uc.benkkstudio.bsvideostatus.data.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.benkkstudio.bsjson.API;
import com.benkkstudio.bsjson.BSJson;
import com.benkkstudio.bsjson.Interface.BSJsonOnSuccessListener;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import uc.benkkstudio.bsvideostatus.R;
import uc.benkkstudio.bsvideostatus.Settings;
import uc.benkkstudio.bsvideostatus.data.base.RecyclerViewClickListener;
import uc.benkkstudio.bsvideostatus.data.model.ModelHome;
import uc.benkkstudio.bsvideostatus.data.utils.Logger;
import uc.benkkstudio.bsvideostatus.data.utils.ProgressLoader;
import uc.benkkstudio.bsvideostatus.data.utils.SharedPref;
import uc.benkkstudio.bsvideostatus.data.utils.Variable;
import uc.benkkstudio.bsvideostatus.data.widgets.TimeAgos;
import uc.benkkstudio.bsvideostatus.ui.main.MainActivity;
import uc.benkkstudio.bsvideostatus.ui.registerlogin.login.LoginPresenter;

public class BookmarkAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Activity activity;
    private ArrayList<ModelHome> arrayList;
    private RecyclerViewClickListener<ModelHome> recyclerViewClickListener;
    private int ITEMS_PER_AD = 4;
    private ProgressLoader progressLoader;
    public BookmarkAdapter(Activity activity, ArrayList<ModelHome> arrayList, RecyclerViewClickListener<ModelHome> recyclerViewClickListener) {
        this.arrayList = new ArrayList<>();
        this.arrayList.addAll(arrayList);
        this.activity = activity;
        this.recyclerViewClickListener = recyclerViewClickListener;
        progressLoader = new ProgressLoader(activity);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.lsv_item_video, parent, false);
        return new HomeHolder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holderPrent, final int position) {
        final HomeHolder holder = (HomeHolder) holderPrent;
        final ModelHome modelHome = arrayList.get(position);
        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
        jsObj.addProperty("method_name", "check_bookmark");
        jsObj.addProperty("vid", modelHome.vid);
        jsObj.addProperty("bookmark_id", SharedPref.getSharedPref(activity).read(LoginPresenter.USER_ID));
        new BSJson.Builder(activity)
                .setServer(Settings.server_url)
                .setObject(jsObj)
                .setPurchaseCode(Settings.purchase_code)
                .setListener(new BSJsonOnSuccessListener() {
                    @Override
                    public void onSuccess(int statusCode, byte[] responseBody) {
                        try {
                            JSONObject jsonObject = new JSONObject(new String(responseBody));
                            JSONArray jsonArray = jsonObject.getJSONArray(Variable.TAG_ROOT);
                            JSONObject objJson = jsonArray.getJSONObject(0);
                            if(objJson.getInt("success") == 1){
                                holder.icon_bookmarks.setImageDrawable(activity.getResources().getDrawable(R.drawable.ic_bookmark_filled));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    @Override
                    public void onFiled(int statusCode, byte[] responseBody, Throwable error) {
                    }
                })
                .load();
        holder.video_title.setText(modelHome.video_title);
        holder.video_uploaded.setText(TimeAgos.parse(modelHome.video_time));
        holder.video_profile.setText(modelHome.modelUsers.user_name);
        holder.text_views_count.setText(String.format("%s Views", modelHome.video_view));
        holder.text_share_count.setText(String.format("%s Share", modelHome.video_share));
        holder.text_comment_count.setText(String.format("%s Comment", modelHome.total_comment));
        holder.icon_bookmarks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressLoader.show();
                JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
                jsObj.addProperty("method_name", "check_bookmark");
                jsObj.addProperty("vid", modelHome.vid);
                jsObj.addProperty("bookmark_id", SharedPref.getSharedPref(activity).read(LoginPresenter.USER_ID));
                new BSJson.Builder(activity)
                        .setServer(Settings.server_url)
                        .setObject(jsObj)
                        .setPurchaseCode(Settings.purchase_code)
                        .setListener(new BSJsonOnSuccessListener() {
                            @Override
                            public void onSuccess(int statusCode, byte[] responseBody) {
                                try {
                                    JSONObject jsonObject = new JSONObject(new String(responseBody));
                                    JSONArray jsonArray = jsonObject.getJSONArray(Variable.TAG_ROOT);
                                    JSONObject objJson = jsonArray.getJSONObject(0);
                                    if(objJson.getInt("success") == 0){
                                        addBookmark(position, holder);
                                    } else {
                                        deleteBookmark(position, holder);
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                progressLoader.stopLoader();
                            }
                            @Override
                            public void onFiled(int statusCode, byte[] responseBody, Throwable error) {
                                progressLoader.stopLoader();
                            }
                        })
                        .load();
            }
        });
        RequestOptions options = new RequestOptions().frame(1);
        Glide.with(activity).asBitmap()
                .load(modelHome.video_url)
                .apply(options)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder)
                .into(holder.image_video);
        Glide.with(activity)
                .load(modelHome.modelUsers.user_image)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
                .placeholder(R.drawable.profile_default)
                .error(R.drawable.profile_default)
                .into(holder.image_profile);
        holder.image_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recyclerViewClickListener.onItemClick(v, modelHome, 1);
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Variable.arrayListDetail = new ArrayList<>();
                Variable.arrayListDetail.addAll(arrayList);
                Variable.view_post_position = position;
                recyclerViewClickListener.onItemClick(view, modelHome, 0);
            }
        });
    }

    private void addBookmark(int position, final HomeHolder holder){
        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
        jsObj.addProperty("method_name", "add_bookmark");
        jsObj.addProperty("vid", arrayList.get(position).vid);
        jsObj.addProperty("bookmark_id", SharedPref.getSharedPref(activity).read(LoginPresenter.USER_ID));
        new BSJson.Builder(activity)
                .setServer(Settings.server_url)
                .setObject(jsObj)
                .setPurchaseCode(Settings.purchase_code)
                .setListener(new BSJsonOnSuccessListener() {
                    @Override
                    public void onSuccess(int statusCode, byte[] responseBody) {
                        holder.icon_bookmarks.setImageDrawable(activity.getResources().getDrawable(R.drawable.ic_bookmark_filled));
                        ((MainActivity)activity).reattachBookmark();
                    }
                    @Override
                    public void onFiled(int statusCode, byte[] responseBody, Throwable error) {
                    }
                })
                .load();
    }

    private void deleteBookmark(int position, final HomeHolder holder){
        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
        jsObj.addProperty("method_name", "delete_bookmark");
        jsObj.addProperty("vid", arrayList.get(position).vid);
        jsObj.addProperty("bookmark_id", SharedPref.getSharedPref(activity).read(LoginPresenter.USER_ID));
        new BSJson.Builder(activity)
                .setServer(Settings.server_url)
                .setObject(jsObj)
                .setPurchaseCode(Settings.purchase_code)
                .setListener(new BSJsonOnSuccessListener() {
                    @Override
                    public void onSuccess(int statusCode, byte[] responseBody) {
                        holder.icon_bookmarks.setImageDrawable(activity.getResources().getDrawable(R.drawable.ic_bookmark));
                        ((MainActivity)activity).reattachBookmark();
                    }
                    @Override
                    public void onFiled(int statusCode, byte[] responseBody, Throwable error) {
                    }
                })
                .load();
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class HomeHolder extends RecyclerView.ViewHolder {
        TextView video_title, video_profile, video_uploaded, text_views_count, text_comment_count, text_share_count;
        ImageView image_video, image_profile, image_play, icon_bookmarks;
        HomeHolder(View itemView) {
            super(itemView);
            video_title = itemView.findViewById(R.id.video_title);
            video_profile = itemView.findViewById(R.id.video_profile);
            video_uploaded = itemView.findViewById(R.id.video_uploaded);
            image_video = itemView.findViewById(R.id.image_video);
            image_profile = itemView.findViewById(R.id.image_profile);
            image_play = itemView.findViewById(R.id.image_play);
            text_views_count = itemView.findViewById(R.id.text_views_count);
            text_comment_count = itemView.findViewById(R.id.text_comment_count);
            text_share_count = itemView.findViewById(R.id.text_share_count);
            icon_bookmarks = itemView.findViewById(R.id.icon_bookmarks);
        }
    }
}