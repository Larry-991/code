package uc.benkkstudio.bsvideostatus.ui.upload;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public interface UploadView extends MvpView {

}
