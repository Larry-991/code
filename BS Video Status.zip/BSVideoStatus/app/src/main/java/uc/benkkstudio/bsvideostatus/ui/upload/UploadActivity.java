package uc.benkkstudio.bsvideostatus.ui.upload;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import uc.benkkstudio.bsvideostatus.R;
import uc.benkkstudio.bsvideostatus.data.base.BaseActivity;
import uc.benkkstudio.bsvideostatus.databinding.ActivityUploadBinding;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import com.bumptech.glide.Glide;
import com.nguyenhoanglam.imagepicker.model.Config;

import java.io.File;
import java.util.Objects;

public class UploadActivity extends BaseActivity<UploadView, UploadPresenter> {
    @Override
    protected int getLayoutId() {
        return R.layout.activity_upload;
    }

    @Override
    protected void onStarting() {
        ActivityUploadBinding binding = DataBindingUtil.setContentView(this, getLayoutId());
        presenter.initView(this, binding);
        binding.toolbar.setTitle("");
        setSupportActionBar(binding.toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        binding.toolbar.setNavigationIcon(getResources().getDrawable(R.drawable.ic_back));
    }

    @Override
    protected void onDestroyed() {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected UploadPresenter initPresenter() {
        return new UploadPresenter();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        presenter.onActivityResult(requestCode, resultCode, data);
    }
}
