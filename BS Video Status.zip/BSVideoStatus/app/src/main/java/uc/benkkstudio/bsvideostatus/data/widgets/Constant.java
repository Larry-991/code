package uc.benkkstudio.bsvideostatus.data.widgets;

import java.io.Serializable;

public class Constant implements Serializable {
    public static String selectedCategories;
    public static int selectedCategoriesPosition;
}
