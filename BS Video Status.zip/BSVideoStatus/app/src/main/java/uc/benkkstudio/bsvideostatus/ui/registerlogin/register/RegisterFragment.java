package uc.benkkstudio.bsvideostatus.ui.registerlogin.register;

import uc.benkkstudio.bsvideostatus.R;
import uc.benkkstudio.bsvideostatus.data.base.BaseFragment;

public class RegisterFragment extends BaseFragment<RegisterView, RegisterPresenter> {
    @Override
    protected void onStarting() {
        presenter.initView(requireActivity(), getRootView());
    }

    @Override
    protected void onDestroyed() {

    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_register;
    }

    @Override
    protected RegisterPresenter initPresenter() {
        return new RegisterPresenter();
    }
}
