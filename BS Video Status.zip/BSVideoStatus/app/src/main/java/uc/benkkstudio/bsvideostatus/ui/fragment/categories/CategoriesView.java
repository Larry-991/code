package uc.benkkstudio.bsvideostatus.ui.fragment.categories;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public interface CategoriesView extends MvpView {
    void onClickListener(int cat_id);
}
