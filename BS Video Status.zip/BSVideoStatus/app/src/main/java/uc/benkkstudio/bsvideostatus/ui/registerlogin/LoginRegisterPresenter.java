package uc.benkkstudio.bsvideostatus.ui.registerlogin;

import uc.benkkstudio.bsvideostatus.data.base.BasePresenter;
import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public class LoginRegisterPresenter extends BasePresenter<LoginRegisterView> {
}
