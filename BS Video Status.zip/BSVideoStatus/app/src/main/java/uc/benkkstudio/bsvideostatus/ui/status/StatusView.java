package uc.benkkstudio.bsvideostatus.ui.status;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public interface StatusView extends MvpView {
}
