package uc.benkkstudio.bsvideostatus.ui.fragment.editprofile;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public interface EditProfileView extends MvpView {
}
