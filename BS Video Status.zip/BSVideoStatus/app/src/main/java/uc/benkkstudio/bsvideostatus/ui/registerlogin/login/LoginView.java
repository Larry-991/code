package uc.benkkstudio.bsvideostatus.ui.registerlogin.login;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public interface LoginView extends MvpView {
}
