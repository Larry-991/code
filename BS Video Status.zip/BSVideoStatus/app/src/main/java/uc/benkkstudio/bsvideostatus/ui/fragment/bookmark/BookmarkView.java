package uc.benkkstudio.bsvideostatus.ui.fragment.bookmark;

import android.view.View;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public interface BookmarkView extends MvpView {
    void startActivity(View view, String tag);
    void callFragmentProfile(int userId);
}
