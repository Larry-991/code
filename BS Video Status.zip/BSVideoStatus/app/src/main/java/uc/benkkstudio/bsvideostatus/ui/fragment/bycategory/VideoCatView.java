package uc.benkkstudio.bsvideostatus.ui.fragment.bycategory;

import android.view.View;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public interface VideoCatView extends MvpView {
    void startActivity(View view, String tag);
    void callFragmentProfile(int userId);
}
