package uc.benkkstudio.bsvideostatus.ui.fragment.profile;

import android.view.View;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public interface ProfileView extends MvpView {
    void startActivity(View view, String tag);
    void editProfile();
}
