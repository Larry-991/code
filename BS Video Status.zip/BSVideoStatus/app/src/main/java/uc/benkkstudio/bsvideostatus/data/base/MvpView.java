package uc.benkkstudio.bsvideostatus.data.base;

public interface MvpView {
}