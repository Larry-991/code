package uc.benkkstudio.bsvideostatus.ui.registerlogin;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public interface LoginRegisterView extends MvpView {
}
