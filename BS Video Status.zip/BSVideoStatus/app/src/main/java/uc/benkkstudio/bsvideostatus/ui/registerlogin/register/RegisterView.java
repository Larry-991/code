package uc.benkkstudio.bsvideostatus.ui.registerlogin.register;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public interface RegisterView extends MvpView {
}
