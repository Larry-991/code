package uc.benkkstudio.bsvideostatus.ui.detail;

import android.view.View;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

public interface DetailView extends MvpView {
    void startActivity(View view, String tag);
}
