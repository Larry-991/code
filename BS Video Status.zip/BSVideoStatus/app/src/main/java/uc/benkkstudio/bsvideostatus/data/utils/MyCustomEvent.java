package uc.benkkstudio.bsvideostatus.data.utils;

public class MyCustomEvent{
    public String data;
    public MyCustomEvent(String data){
        this.data=data;
    }
}