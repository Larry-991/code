package uc.benkkstudio.bsvideostatus.ui.main;

import android.view.View;

import uc.benkkstudio.bsvideostatus.data.base.MvpView;

interface MainView extends MvpView {
    void whatsappClick();
    void homeNavClick();
    void categoriesNavClick();
    void bookmarkNavClick();
    void profileNavClick();
    void startActivity(View view);
    void onUpload();
    void centreClick();
}
