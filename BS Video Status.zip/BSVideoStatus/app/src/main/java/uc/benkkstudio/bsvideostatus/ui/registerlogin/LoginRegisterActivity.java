package uc.benkkstudio.bsvideostatus.ui.registerlogin;

import androidx.appcompat.app.AppCompatActivity;
import uc.benkkstudio.bsvideostatus.R;
import uc.benkkstudio.bsvideostatus.data.base.BaseActivity;
import uc.benkkstudio.bsvideostatus.ui.registerlogin.login.LoginFragment;
import uc.benkkstudio.bsvideostatus.ui.registerlogin.register.RegisterFragment;

import android.os.Bundle;

public class LoginRegisterActivity extends BaseActivity<LoginRegisterView, LoginRegisterPresenter> {
    @Override
    protected int getLayoutId() {
        return R.layout.activity_login_register;
    }

    @Override
    protected void onStarting() {
        callFragment(R.id.fragment_container, new LoginFragment());
    }

    public void callRegisterFragment(){
        callFragment(R.id.fragment_container, new RegisterFragment());
    }

    public void callLoginFragment(){
        callFragment(R.id.fragment_container, new LoginFragment());
    }
    @Override
    protected void onDestroyed() {

    }

    @Override
    protected LoginRegisterPresenter initPresenter() {
        return new LoginRegisterPresenter();
    }
}
